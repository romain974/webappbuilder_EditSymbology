///////////////////////////////////////////////////////////////////////////
// Copyright © 2014 Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////

define([
		'dojo/_base/declare',
		'dojo/_base/lang',
		'dojo/_base/array',
		'dojo/_base/html',
		'dojo/_base/query',
		'dojo/on',
		'dijit/_WidgetsInTemplateMixin',
		'jimu/BaseWidgetSetting',
		'jimu/dijit/TabContainer',
		'jimu/utils',
		'dijit/form/Select',
		'jimu/dijit/CheckBox',
		'jimu/dijit/SimpleTable',
		'jimu/dijit/Message'
	],
	function (declare, lang, array, html, query, on, _WidgetsInTemplateMixin, BaseWidgetSetting,
		TabContainer, jimuUtils, Select, CheckBox, SimpleTable, Message) {

	return declare([BaseWidgetSetting, _WidgetsInTemplateMixin], {
		baseClass : 'jimu-widget-draw-setting',
		distanceUnits : null,
		areaUnits : null,

		_disabledClass : "jimu-state-disabled",
		localStorageKeyMessage : function () {
			new Message({
				message : this.nls.localStorageKeyInfo
			});

		},

		postMixInProperties : function () {
			this.inherited(arguments);

			this.distanceUnits = [{
					value : 'KILOMETERS',
					label : this.nls.kilometers,
					abbr : this.nls.kilometersAbbreviation || 'km',
					conversion : jimuUtils.localizeNumber(0.001, {
						places : 3
					})
				}, {
					value : 'MILES',
					label : this.nls.miles,
					abbr : this.nls.milesAbbreviation || 'mi',
					conversion : jimuUtils.localizeNumber(0.000621, {
						places : 6
					})
				}, {
					value : 'METERS',
					label : this.nls.meters,
					abbr : this.nls.metersAbbreviation || 'm',
					conversion : jimuUtils.localizeNumber(1)
				}, {
					value : 'NAUTICAL_MILES',
					label : this.nls.nauticals,
					abbr : this.nls.nauticalsAbbreviation || 'nm',
					conversion : jimuUtils.localizeNumber(0.00053957, {
						places : 7
					})
				}, {
					value : 'FEET',
					label : this.nls.feet,
					abbr : this.nls.feetAbbreviation || 'ft',
					conversion : jimuUtils.localizeNumber(3.2808, {
						places : 4
					})
				}, {
					value : 'YARDS',
					label : this.nls.yards,
					abbr : this.nls.yardsAbbreviation || 'yd',
					conversion : jimuUtils.localizeNumber(1.0936133, {
						places : 7
					})
				}
			];

			this.areaUnits = [{
					value : 'SQUARE_KILOMETERS',
					label : this.nls.squareKilometers,
					abbr : this.nls.squareKilometersAbbreviation || 'sq km',
					conversion : jimuUtils.localizeNumber(0.000001, {
						places : 6
					})
				}, {
					value : 'SQUARE_MILES',
					label : this.nls.squareMiles,
					abbr : this.nls.squareMilesAbbreviation || 'sq mi',
					conversion : jimuUtils.localizeNumber(3.861021, {
						places : 6
					}) + 'e-7'
					//0.0000003861021
				}, {
					value : 'ACRES',
					label : this.nls.acres,
					abbr : this.nls.acresAbbreviation || 'ac',
					conversion : jimuUtils.localizeNumber(0.00024710538147, {
						places : 14
					})
				}, {
					value : 'HECTARES',
					label : this.nls.hectares,
					abbr : this.nls.hectaresAbbreviation || 'ha',
					conversion : jimuUtils.localizeNumber(0.0001, {
						places : 4
					})
				}, {
					value : 'SQUARE_METERS',
					label : this.nls.squareMeters,
					abbr : this.nls.squareMetersAbbreviation || 'sq m',
					conversion : jimuUtils.localizeNumber(1)
				}, {
					value : 'SQUARE_FEET',
					label : this.nls.squareFeet,
					abbr : this.nls.squareFeetAbbreviation || 'sq ft',
					conversion : jimuUtils.localizeNumber(10.763910417, {
						places : 9
					})
				}, {
					value : 'SQUARE_YARDS',
					label : this.nls.squareYards,
					abbr : this.nls.squareYardsAbbreviation || 'sq yd',
					conversion : jimuUtils.localizeNumber(1.19599005, {
						places : 8
					})
				}
			];
		},

		postCreate : function () {
			this.inherited(arguments);
			// this.cbxOperationalLayer = new CheckBox({
			// label : this.nls.operationalLayer,
			// style : 'margin-top:10px;'
			// });
			// html.addClass(this.cbxOperationalLayer.domNode, 'tip');
			// this.cbxOperationalLayer.placeAt(this.domNode);
			this.own(on(this.btnAddDistance, 'click', lang.hitch(this, this._addDistance)));
			this.own(on(this.btnAddArea, 'click', lang.hitch(this, this._addArea)));
			this.own(on(this.btnAddFontFamily, 'click', lang.hitch(this, this._addFontFamily)));
			this.own(on(this.distanceTable, 'row-delete', lang.hitch(this, function (tr) {
						if (tr.select) {
							tr.select.destroy();
							delete tr.select;
						}
						this._resetDistanceSelectOptions();
						this._checkStatusForBtnAddDistance();
					})));
			this.own(on(this.areaTable, 'row-delete', lang.hitch(this, function (tr) {
						if (tr.select) {
							tr.select.destroy();
							delete tr.select;
						}
						this._resetAreaSelectOptions();
						this._checkStatusForBtnAddArea();
					})));
			this.setConfig(this.config);
		},

		startup : function () {
			this.inherited(arguments);

			this.tabContainer = new TabContainer({
					tabs : [{
							title : this.nls.distance,
							content : this.distanceTabNode
						}, {
							title : this.nls.area,
							content : this.areaTabNode
						}
					],
					isNested : true
				}, this.content);
			this.tabContainer.startup();
		},

		setConfig : function (config) {
			config.isOperationalLayer = !!config.isOperationalLayer;
			this.config = config;
			this._setDistanceTable(this.config.distanceUnits);
			this._setAreaTable(this.config.areaUnits);
			// this.cbxOperationalLayer.setValue(config.isOperationalLayer);

			this._setTextPlusFontFamilyTable(this.config);

			this.exportFileNameInput.value = (config.exportFileName) ? config.exportFileName : this.nls.exportFileName;
			this.confirmOnDeleteInput.checked = (config.confirmOnDelete) ? true : false;
			this.listShowUpAndDownButtons.checked = (config.listShowUpAndDownButtons) ? true : false;
			this.allowLocalStorageInput.checked = (config.allowLocalStorage) ? true : false;
			this.localStorageKeyInput.value = (config.localStorageKey) ? config.localStorageKey : '';

			//Text plus FontFamily
			this._setTextPlusFontFamilyTable(config);

			//Measure config
			this.measureEnabledByDefaultInput.checked = (config.measureEnabledByDefault);
			this.measurePolylineLabelInput.value = (config.measurePolylineLabel && config.measurePolylineLabel.trim() != "") ? config.measurePolylineLabel.trim() : "{{length}} {{lengthUnit}}";
			this.measurePolygonLabelInput.value = (config.measurePolygonLabel && config.measurePolygonLabel.trim() != "") ? config.measurePolygonLabel.trim() : "{{area}} {{areaUnit}}    {{length}} {{lengthUnit}}";
		},

		_setTextPlusFontFamilyTable : function (config) {
			var options =
				(config.drawPlus && config.drawPlus.fontFamilies && config.drawPlus.fontFamilies.length > 0) ? config.drawPlus.fontFamilies : [{
					"label" : "Arial",
					"value" : "Arial"
				}, {
					"label" : "Helvetica",
					"value" : "Helvetica"
				}, {
					"label" : "Times New Roman",
					"value" : "Times New Roman"
				}, {
					"label" : "Courier New",
					"value" : "Courier New"
				}
			];

			this.textPlusFontFamilyTable.clear();
			for (var i in options)
				this.textPlusFontFamilyTable.addRow(options[i]);
		},

		_setDistanceTable : function (distanceUnits) {
			this.distanceTable.clear();
			array.forEach(distanceUnits, lang.hitch(this, function (item) {
					var defaultUnitInfo = this._getDistanceUnitInfo(item.unit);
					if (!defaultUnitInfo) {
						return;
					}
					defaultUnitInfo.abbr = item.abbr;
					this._addDistanceUnitRow(defaultUnitInfo);
				}));
		},

		_setAreaTable : function (areaUnits) {
			this.areaTable.clear();
			array.forEach(areaUnits, lang.hitch(this, function (item) {
					var defaultUnitInfo = this._getAreaUnitInfo(item.unit);
					if (!defaultUnitInfo) {
						return;
					}
					defaultUnitInfo.abbr = item.abbr;
					this._addAreaUnitRow(defaultUnitInfo);
				}));
		},

		getConfig : function () {
			var config = {
				distanceUnits : [],
				areaUnits : [],
				isOperationalLayer : false
			};
			config.distanceUnits = this._getDistanceConfig();
			config.areaUnits = this._getAreaConfig();
			// config.isOperationalLayer = this.cbxOperationalLayer.getValue();

			config.exportFileName = (this.exportFileNameInput.value.trim() != "") ? this.exportFileNameInput.value.trim() : this.nls.exportFileName;
			config.confirmOnDelete = this.confirmOnDeleteInput.checked;
			config.listShowUpAndDownButtons = this.listShowUpAndDownButtons.checked;
			config.allowLocalStorage = this.allowLocalStorageInput.checked;
			var key = this.localStorageKeyInput.value.trim();
			config.localStorageKey = (key == "") ? false : key;

			if (!config["drawPlus"])
				config["drawPlus"] = {};
			var FontFamilyOptions = array.map(this.textPlusFontFamilyTable.getRows(), lang.hitch(this, function (tr) {
						var data = this.textPlusFontFamilyTable.getRowData(tr);
						return {
							"value" : data.value,
							"label" : data.label
						}
					}));
			config["drawPlus"]["fontFamilies"] = FontFamilyOptions;

			// Measure
			config.measureEnabledByDefault = this.measureEnabledByDefaultInput.checked;
			config.measurePolylineLabel = (this.measurePolylineLabelInput.value && this.measurePolylineLabelInput.value.trim() != "") ? this.measurePolylineLabelInput.value : false;
			config.measurePolygonLabel = (this.measurePolygonLabelInput.value && this.measurePolygonLabelInput.value.trim() != "") ? this.measurePolygonLabelInput.value : false;

      for(var name in this.config){
        if(!config[name]){
          config[name] = this.config[name];
        }
      }
      if(!config.defaultSymbols){
        config["defaultSymbols"] = {
          "SimpleMarkerSymbol":{"color":[255,199,198,148],"size":15,"angle":0,"xoffset":0,"yoffset":0,"type":"esriSMS","style":"esriSMSCircle","outline":{"color":[207,101,99,255],"width":0.75,"type":"esriSLS","style":"esriSLSSolid"}},
          "SimpleLineSymbol": {"color":[207,101,99,255],"width":1.5,"type":"esriSLS","style":"esriSLSSolid"},
          "SimpleFillSymbol": {"color":[255,199,198,148],"outline":{"color":[207,101,99,255],"width":0.75,"type":"esriSLS","style":"esriSLSSolid"},"type":"esriSFS","style":"esriSFSSolid"},
          "TextSymbol":false,
          "MeasureSymbol":{
            "color": [0, 0, 0, 255],
            "type": "esriTS",
            "verticalAlignment": "middle",
            "horizontalAlignment": "center",
            "angle": 0,
            "xoffset": 0,
            "yoffset": 0,
            "text": "Measure",
            "rotated": false,
            "kerning": true,
            "font": {
              "size": 12,
              "style": "italic",
              "decoration": "none",
              "weight": "bold",
              "family": "Courier New"
            }
          }
        }
      }
      console.log("eDraw -> new config : ", config);
			return config;
		},

		_getDistanceConfig : function () {
			var result = [];
			var trs = this.distanceTable.getRows();
			result = array.map(trs, lang.hitch(this, function (tr) {
						var data = this.distanceTable.getRowData(tr);
						var select = tr.select;
						var unitInfo = {
							unit : select.get('value'),
							abbr : data.abbr
						};
						return unitInfo;
					}));
			return result;
		},

		_getAreaConfig : function () {
			var result = [];
			var trs = this.areaTable.getRows();
			result = array.map(trs, lang.hitch(this, function (tr) {
						var data = this.areaTable.getRowData(tr);
						var select = tr.select;
						var unitInfo = {
							unit : select.get('value'),
							abbr : data.abbr
						};
						return unitInfo;
					}));
			return result;
		},

		_getAllDistanceUnitValues : function () {
			var distanceUnitValues = array.map(this.distanceUnits, lang.hitch(this, function (item) {
						return item.value;
					}));
			return distanceUnitValues;
		},

		_getUsedDistanceUnitValues : function () {
			var trs = this.distanceTable.getRows();
			var usedDistanceUnitValues = array.map(trs, lang.hitch(this, function (tr) {
						return tr.select.get('value');
					}));
			return usedDistanceUnitValues;
		},

		_getNotUsedDistanceUnitValues : function () {
			var allValues = this._getAllDistanceUnitValues();
			var usedValues = this._getUsedDistanceUnitValues();
			var notUsedValues = array.filter(allValues, lang.hitch(this, function (item) {
						return array.indexOf(usedValues, item) < 0;
					}));
			return notUsedValues;
		},

		_getDistanceUnitInfo : function (value) {
			var result = null;
			var units = array.filter(this.distanceUnits, lang.hitch(this, function (unit) {
						return unit.value === value;
					}));
			if (units.length > 0) {
				result = lang.mixin({}, units[0]);
			}
			return result;
		},

		_addFontFamily : function () {
			console.log("Add font family");
			var data = {
				"label" : "New font family",
				"value" : "New font family"
			};
			var result = this.textPlusFontFamilyTable.addRow(data);
			if (result)
				this.textPlusFontFamilyTable.editRow(result.tr, data);
		},

		_addDistance : function () {
			var notUsedValues = this._getNotUsedDistanceUnitValues();
			if (notUsedValues.length === 0) {
				return;
			}
			var value = notUsedValues[0];
			var unitInfo = this._getDistanceUnitInfo(value);
			this._addDistanceUnitRow(unitInfo);
		},

		_checkStatusForBtnAddDistance : function () {
			var notUsedValues = this._getNotUsedDistanceUnitValues();
			if (notUsedValues.length === 0) {
				html.addClass(this.btnAddDistance, this._disabledClass);
				html.addClass(this.btnAddDistanceIcon, this._disabledClass);
			} else {
				html.removeClass(this.btnAddDistance, this._disabledClass);
				html.removeClass(this.btnAddDistanceIcon, this._disabledClass);
			}
		},

		_addDistanceUnitRow : function (unitInfo) {
			var rowData = {
				abbr : unitInfo.abbr,
				conversion : unitInfo.conversion
			};
			var result = this.distanceTable.addRow(rowData);
			if (result.success && result.tr) {
				var tr = result.tr;
				var td = query('.simple-table-cell', tr)[0];
				html.setStyle(td, "verticalAlign", "middle");
				var select = new Select({
						style : "width:100%;height:18px;line-height:18px;"

					});
				select.placeAt(td);
				select.startup();
				select.addOption({
					value : unitInfo.value,
					label : unitInfo.label,
					selected : true
				});
				this.own(on(select, 'change', lang.hitch(this, this._resetDistanceSelectOptions)));
				tr.select = select;
			}
			this._resetDistanceSelectOptions();
			this._checkStatusForBtnAddDistance();
		},

		_showCorrectDistanceInfoBySelectedOption : function (tr) {
			var select = tr.select;
			var unitInfo = this._getDistanceUnitInfo(select.value);
			var rowData = {
				abbr : unitInfo.abbr,
				conversion : unitInfo.conversion
			};
			this.distanceTable.editRow(tr, rowData);
		},

		_resetDistanceSelectOptions : function () {
			var trs = this.distanceTable.getRows();
			var selects = array.map(trs, lang.hitch(this, function (tr) {
						return tr.select;
					}));
			var notUsedValues = this._getNotUsedDistanceUnitValues();
			var notUsedUnitsInfo = array.map(notUsedValues, lang.hitch(this, function (value) {
						return this._getDistanceUnitInfo(value);
					}));
			array.forEach(selects, lang.hitch(this, function (select, index) {
					var currentValue = select.get('value');
					var notSelectedOptions = array.filter(select.getOptions(),
							lang.hitch(this, function (option) {
								return option.value !== currentValue;
							}));
					select.removeOption(notSelectedOptions);
					array.forEach(notUsedUnitsInfo, lang.hitch(this, function (unitInfo) {
							select.addOption({
								value : unitInfo.value,
								label : unitInfo.label
							});
						}));
					select.set('value', currentValue);
					var tr = trs[index];
					this._showCorrectDistanceInfoBySelectedOption(tr);
				}));
		},

		_getAllAreaUnitValues : function () {
			var areaUnitValues = array.map(this.areaUnits, lang.hitch(this, function (item) {
						return item.value;
					}));
			return areaUnitValues;
		},

		_getUsedAreaUnitValues : function () {
			var trs = this.areaTable.getRows();
			var usedAreaUnitValues = array.map(trs, lang.hitch(this, function (tr) {
						return tr.select.get('value');
					}));
			return usedAreaUnitValues;
		},

		_getNotUsedAreaUnitValues : function () {
			var allValues = this._getAllAreaUnitValues();
			var usedValues = this._getUsedAreaUnitValues();
			var notUsedValues = array.filter(allValues, lang.hitch(this, function (item) {
						return array.indexOf(usedValues, item) < 0;
					}));
			return notUsedValues;
		},

		_getAreaUnitInfo : function (value) {
			var result = null;
			var units = array.filter(this.areaUnits, lang.hitch(this, function (unit) {
						return unit.value === value;
					}));
			if (units.length > 0) {
				result = lang.mixin({}, units[0]);
			}
			return result;
		},

		_addArea : function () {
			var notUsedValues = this._getNotUsedAreaUnitValues();
			if (notUsedValues.length === 0) {
				return;
			}
			var value = notUsedValues[0];
			var unitInfo = this._getAreaUnitInfo(value);
			this._addAreaUnitRow(unitInfo);
		},

		_checkStatusForBtnAddArea : function () {
			var notUsedValues = this._getNotUsedAreaUnitValues();
			if (notUsedValues.length === 0) {
				html.addClass(this.btnAddArea, this._disabledClass);
				html.addClass(this.btnAddAreaIcon, this._disabledClass);
			} else {
				html.removeClass(this.btnAddArea, this._disabledClass);
				html.removeClass(this.btnAddAreaIcon, this._disabledClass);
			}
		},

		_addAreaUnitRow : function (unitInfo) {
			var rowData = {
				abbr : unitInfo.abbr,
				conversion : unitInfo.conversion
			};
			var result = this.areaTable.addRow(rowData);
			if (result.success && result.tr) {
				var tr = result.tr;
				var td = query('.simple-table-cell', tr)[0];
				html.setStyle(td, "verticalAlign", "middle");
				var select = new Select({
						style : "width:100%;height:18px;line-height:18px;"

					});
				select.placeAt(td);
				select.startup();
				select.addOption({
					value : unitInfo.value,
					label : unitInfo.label,
					selected : true
				});
				this.own(on(select, 'change', lang.hitch(this, this._resetAreaSelectOptions)));
				tr.select = select;
			}
			this._resetAreaSelectOptions();
			this._checkStatusForBtnAddArea();
		},

		_showCorrectAreaInfoBySelectedOption : function (tr) {
			var select = tr.select;
			var unitInfo = this._getAreaUnitInfo(select.value);
			var rowData = {
				abbr : unitInfo.abbr,
				conversion : unitInfo.conversion
			};
			this.areaTable.editRow(tr, rowData);
		},

		_resetAreaSelectOptions : function () {
			var trs = this.areaTable.getRows();
			var selects = array.map(trs, lang.hitch(this, function (tr) {
						return tr.select;
					}));
			var notUsedValues = this._getNotUsedAreaUnitValues();
			var notUsedUnitsInfo = array.map(notUsedValues, lang.hitch(this, function (value) {
						return this._getAreaUnitInfo(value);
					}));
			array.forEach(selects, lang.hitch(this, function (select, index) {
					var currentValue = select.get('value');
					var notSelectedOptions = array.filter(select.getOptions(),
							lang.hitch(this, function (option) {
								return option.value !== currentValue;
							}));
					select.removeOption(notSelectedOptions);
					array.forEach(notUsedUnitsInfo, lang.hitch(this, function (unitInfo) {
							select.addOption({
								value : unitInfo.value,
								label : unitInfo.label
							});
						}));
					select.set('value', currentValue);
					var tr = trs[index];
					this._showCorrectAreaInfoBySelectedOption(tr);
				}));
		}

	});
});
