﻿define({
    root:({
        title: "Ajouter des données SHAPEFILE"
    }),
});
