define([
    'jimu/BaseWidget',
    'dojo/_base/declare',
	'dijit/_WidgetsInTemplateMixin',
	'dojo/_base/lang',
	'dojo/on',
	'dojo',
	'dojo/_base/html',
	'dojo/query',
	'./xlsx.min',
	'./PapaParse/papaparse',
	"esri/geometry/jsonUtils",
	"esri/graphic",
	"esri/layers/FeatureLayer",
	"esri/graphicsUtils",
	"jimu/LayerStructure",
	"esri/geometry/webMercatorUtils",
	"esri/symbols/SimpleMarkerSymbol",
	"esri/symbols/SimpleLineSymbol",
	"esri/symbols/SimpleFillSymbol",
	"esri/renderers/SimpleRenderer",
	'jimu/dijit/LoadingShelter',
	"esri/geometry/Point",
	"esri/SpatialReference",
	"esri/geometry/projection",
  ],
  function(BaseWidget, declare, _WidgetsInTemplateMixin, lang, on, dojo,html,query,XLSX,papaparse,geometryJsonUtils,Graphic,FeatureLayer,graphicsUtils,LayerStructure,webMercatorUtils,SimpleMarkerSymbol,SimpleLineSymbol,SimpleFillSymbol,SimpleRenderer,LoadingShelter,Point,SpatialReference,projection) {

    var clazz = declare([BaseWidget, _WidgetsInTemplateMixin], {
      //these two properties is defined in the BaseWiget
      baseClass: 'jimu-widget-AddXYTable',
      name: 'AddXYTable',

      startup: function() {
        this.inherited(arguments);
		
		this.layerStructureInstance = LayerStructure.getInstance();
		
		this.layers={};
		this.file=null;
		this.reader=null;
		this.json=false;

		//actions
		on(this.input_table,'change',lang.hitch(this, this.Read));
		on(this.upload,'click',lang.hitch(this, this.Upload));
		
      }, 
		preconfigure: function(){
			html.empty(this.X_field);
			html.empty(this.Y_field);
			//console.log(this.json);
			x_found=false;
			y_found=false;
			this.fields=[];
			this.fields.push({
				"name":"stinger_uuid",
				"alias":"ID unique",
				"type":"esriFieldTypeOID"
			});
			for(field of Object.keys(this.json[0])){
				if(this.json[0][field] instanceof Date){
					this.fields.push({
						"name":field,
						"alias":field,
						"type":"esriFieldTypeDate"
					});
				}else if(["number","bigint","boolean"].includes(typeof(this.json[0][field]))){
					this.fields.push({
						"name":field,
						"alias":field,
						"type":"esriFieldTypeDouble"
					});
				}else{
					this.fields.push({
						"name":field,
						"alias":field,
						"type":"esriFieldTypeString"
					})
				};
				new_option = new Option(field,field);
				if(x_found==false && (field.toLowerCase().includes("x")||field.toLowerCase().includes("lon"))){
					new_option = new Option(field,field,true,true);
					x_found=true;
				}
				this.X_field.add(new_option,undefined);
				new_option = new Option(field,field);
				if(y_found==false && (field.toLowerCase().includes("y")||field.toLowerCase().includes("lat"))){
					new_option = new Option(field,field,true,true);
					y_found=true;
				}
				this.Y_field.add(new_option,undefined);
			};
			this.shelter.hide();
		},
		Read: function(){
			this.shelter.show();
			this.upload.disabled=false;
			this.X_field.disabled=false
			this.Y_field.disabled=false;
			this.srs.disabled=false;
			this.json=false;
			this.file=this.input_table.files[0];
			if(this.file.name.toLowerCase().endsWith(".xls")||this.file.name.toLowerCase().endsWith(".xlsx")||this.file.name.toLowerCase().endsWith(".ods")){
				//Import Excel
				this.reader = new FileReader();
				this.reader.onload = lang.hitch(this,function(e) {
					var data = e.target.result;
					var workbook = XLSX.read(data, {
					type: 'binary'
					});
					this.json = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[workbook.SheetNames[0]]);
					this.preconfigure();
				});
				this.reader.onerror = lang.hitch(this,function(ex) {
					console.log(ex);
					alert("Erreur lecture fichier Excel");
					this.shelter.hide();
				});
				this.reader.readAsBinaryString(this.file);
			}else{
				//Import TXT
				papaparse.parse(this.file,{
					header: true,
					dynamicTyping: true,
					skipEmptyLines: true,
					complete: lang.hitch(this, function(results, file) {
						console.log("Parsing complete:", results, file);
						this.json=results.data;
						this.preconfigure();
					}),
					error: lang.hitch(this, function(errors, file) {
						alert("Erreur lecture fichier");
						console.log(errors);
						this.shelter.hide();
					})
				});
			};
		},
		Upload: function() {
			if (this.json==false){
				alert("Choisir un fichier à importer");
				return;
			}
			this.shelter.show();
			//configure graphics
			graphics=[];
			sr=new SpatialReference(parseInt(this.srs.value));
			uuid=0;
			errors=[]; // lines errors
			for(row of this.json){
				//valid row
				if(!(this.X_field.value in row) || !(this.X_field.value in row) ){
					errors.push(uuid+2); //consider header + 1
					uuid=uuid+1;
					continue
				}
				if(row[this.X_field.value]==null || row[this.Y_field.value]==null ){
					errors.push(uuid+2); //consider header + 1
					uuid=uuid+1;
					continue
				}
				//valid geometry
				X=parseFloat(row[this.X_field.value].toString().replace(",","."));
				Y=parseFloat(row[this.Y_field.value].toString().replace(",","."));
				if(isNaN(X) ||isNaN(Y)){
					errors.push(uuid+2);
					uuid=uuid+1;
					continue
				}
				geom=new Point(X,Y, sr);
				//console.log(sr);
				/*if(!sr.equals(this.map.spatialReference)){ //reprojection if needed
					if(webMercatorUtils.canProject(sr,this.map.spatialReference)){ //webmercator projection
						new_geom=webMercatorUtils.project(geom, this.map.spatialReference);
					}else{ //other projection
						projection.load().then()
						new_geom=projection.project(geom,this.map.spatialReference,projection.getTransformation(sr,this.map.spatialReference));
					};
				}else{
					new_geom=geom;
				};*/
				new_geom=geom;
				//attributs
				attributs=JSON.parse(JSON.stringify(row));;
				attributs["stinger_uuid"]=uuid;
				uuid=uuid+1;
				//Graphic
				graphic=new Graphic(new_geom,undefined,attributs);
				graphics.push(graphic);//.toJson());
			};
			if(errors.length>0){
				alert("Erreur d'import des lignes suivantes (vérifier si X,Y sont renseignées et numériques): "+errors.join(", "));
			}
			if(uuid==0){
				alert("Aucun point importé");
				this.reset();
				return
			}
			//reprojection if needed
			if(!sr.equals(this.map.spatialReference)){
				new_graphics=[];
				if(webMercatorUtils.canProject(sr,this.map.spatialReference)){ //webmercator projection
					console.log("reprojection webmercator");
					for(graphic of graphics){
						new_geom=webMercatorUtils.project(graphic.geometry, this.map.spatialReference);
						new_graphics.push(new Graphic(new_geom,undefined,graphic.attributes));
					};
					this.createLayer(new_graphics);
				}else{ //other projection
					this.graphics=graphics;
					projection.load().then(lang.hitch(this,function(){
						console.log("reprojection lambert");
						new_graphics=[];
						for(graphic of this.graphics){
							//transfo=projection.getTransformation(graphic.geometry.spatialReference,this.map.spatialReference);
							new_geom=projection.project(graphic.geometry,this.map.spatialReference);
							new_graphics.push(new Graphic(new_geom,undefined,graphic.attributes));
						};
						this.createLayer(new_graphics);
						
					}));
				};
			}else{
				this.createLayer(graphics);
			};
		},
		createLayer: function(graphics_){
			graphics=[];
			for(graphic of graphics_){
				graphics.push(graphic.toJson());
			};
			//create featurelayer
			var featureCollection = {
			  "layerDefinition": null,
			  "featureSet": {
				"features": graphics,
				"geometryType": "esriGeometryPoint"
			  }
			};
			featureCollection.layerDefinition = {
			  "geometryType": "esriGeometryPoint",
			  "objectIdField": "stinger_uuid",
			  "fields": this.fields
			};
			//create unique ID:
			id=this.file.name.split(".")[0];
			while ((id in this.layers)||this.map.layerIds.includes(id)) {
			  id+="_2";
			}
			//create a feature layer based on the feature collection
			featureLayer = new FeatureLayer(featureCollection, {
			  "id": id,
			  "name":id
			  //infoTemplate: popupTemplate
			});
			this.map.addLayer(featureLayer);
			this.layers[featureLayer.id]=featureLayer;
			//activer popup
			this.layer=featureLayer;
			featureLayer.on('load',lang.hitch(this, function(){
				layernode=this.layerStructureInstance.getNodeById(this.layer.id);
				layernode.enablePopup();
			}))
			//create table row
			  var s2 = '';
			  s2 = '<tr class="layer-tr">' +
				  '<td class="layername-td">' +
					'<div class="layername-div">'+featureLayer.id+'</div>' +
				  '</td>' +
				  '<td class="layeralias-td">' +
					'<input type="text" class="layeralias-div" value="'+featureLayer.id+'"/>' +
				  '</td>' +
				  '<td class="action-td">' +
					'<div class="delete-div jimu-icon jimu-icon-delete"></div>' +
				  '</td>' +
				'</tr>';
			  var trDom2 = html.toDom(s2);
			  html.place(trDom2, this.LayersConfig);
			  //rename action
			  var aliasDiv = query('.layeralias-div', trDom2)[0];		  
			  this.own(on(aliasDiv, 'change', lang.hitch(this, function(event){
				event.stopPropagation();
				layer=this.layers[query('.layername-div', trDom2)[0].innerHTML];
				//rename layer
				layer.name=query('.layeralias-div', trDom2)[0].value;
				this.map.removeLayer(layer);
				this.map.addLayer(layer);
			  })));
			  //delete action
			  var deleteDiv = query('.delete-div', trDom2)[0];		  
			  this.own(on(deleteDiv, 'click', lang.hitch(this, function(event){
				event.stopPropagation();
				//remove layer from map
				this.map.removeLayer(this.layers[query('.layername-div', trDom2)[0].innerHTML]);
				//clean layers
				delete this.layers[query('.layername-div', trDom2)[0].innerHTML];
				//clean table
				html.destroy(trDom2);
			  })));
			if(this.zoom.checked){
				this.map.setExtent(graphicsUtils.graphicsExtent(graphics));
			};
			this.reset();
			
		}, 
		reset: function(){
			this.shelter.hide();
			this.upload.disabled=true;
			html.empty(this.X_field);
			html.empty(this.Y_field);
			this.X_field.disabled=true;
			this.Y_field.disabled=true;
			this.input_table.value="";
		},			
		destroy: function() {
        this.inherited(arguments);
      },
	});

    return clazz;
  });
