define([
    'jimu/BaseWidget',
    'dojo/_base/declare',
	'dijit/_WidgetsInTemplateMixin',
	'dojo/_base/lang',
	"esri/graphic",
	"esri/layers/GraphicsLayer",
	"esri/symbols/SimpleMarkerSymbol",
	"esri/geometry/Point",
	"esri/SpatialReference",
	'esri/config',
	"esri/tasks/ProjectParameters",
	"dijit/form/Select",
	"dojo/domReady!",
  ],
  function(BaseWidget, declare, _WidgetsInTemplateMixin, lang, Graphic,GraphicsLayer, SimpleMarkerSymbol,Point,SpatialReference, esriConfig, ProjectParameters) {

    var clazz = declare([BaseWidget, _WidgetsInTemplateMixin], {
      //these two properties is defined in the BaseWiget
      baseClass: 'jimu-widget-ConvertXY',
      name: 'ConvertXY',

      startup: function() {
        this.inherited(arguments);
		//get projection from config file (  text multilines: 1 line/ projection:    epsg; name   (separator: ;)
		for(el in this.config.EPSG.split("\n")){
				option1 = document.createElement("option");
				option1.value=this.config.EPSG.split("\n")[el].split(";")[0];
				option1.text=this.config.EPSG.split("\n")[el].split(";")[1];
				this.srid_dest.appendChild(option1);
				option2 = document.createElement("option");
				option2.value=this.config.EPSG.split("\n")[el].split(";")[0];
				option2.text=this.config.EPSG.split("\n")[el].split(";")[1];
				this.srid_source.appendChild(option2);
		};
		
		//Draw layer
		this.GraphicLayer = new GraphicsLayer();
		this.map.addLayer(this.GraphicLayer);
		//Desactivate popup
		this.map.setInfoWindowOnClick(false);
		// connecter clic carte => get XY
		this.map.onClick=lang.hitch(this, this.getMapXY);
		this.localiser.onclick=lang.hitch(this, this.setMapXY);
		this.convert.onclick=lang.hitch(this, this.convertXY);
		// connecter changement X,Y
		this.X.onchange=lang.hitch(this, this.reset);
		this.Y.onchange=lang.hitch(this, this.reset);
		this.srid_source.onchange=lang.hitch(this, this.reset);
		this.srid_dest.onchange=lang.hitch(this, this.reset);
		},
		reset: function(){
			this.X2.value= null;
			this.Y2.value= null;
			this.GraphicLayer.clear();
		},
		
		convertXY: function(){
			if(!(this.X.value&&this.Y.value&&this.srid_source.value&&this.srid_dest.value)){
				alert(this.nls.erreur2);
				return
			};
			//draw point on map
			this.setMapXY();
			//convert projection
			srid_0 = new SpatialReference(parseInt(this.srid_source.value));
			srid_1 = new SpatialReference(parseInt(this.srid_dest.value));
			if(srid_0.equals(srid_1)){ // même srid
				this.X2.value=this.X.value;
				this.Y2.value=this.Y.value;
			}else{ //reprojection
				pt = new Point(this.X.value,this.Y.value,srid_0)
				var params = new ProjectParameters();
				params.geometries = [pt];
				params.outSR = srid_1;
				esriConfig.defaults.geometryService.project(params, lang.hitch(this, function(geometry){
					this.X2.value=Math.round(geometry[0].x * 1000) / 1000;
					this.Y2.value=Math.round(geometry[0].y * 1000) / 1000;
				}), lang.hitch(this, function(error){alert(this.nls.erreur3+":"+error)}));
			};
		},
		
		getMapXY: function(evt){
			//Draw point
			symbol = new SimpleMarkerSymbol();
			geometry = new Point(evt.mapPoint.x,evt.mapPoint.y,this.map.spatialReference)
			graphic = new Graphic(geometry, symbol);
			this.GraphicLayer.clear();
			this.GraphicLayer.add(graphic);
			//Get XY with specified projection
			sr=new SpatialReference(parseInt(this.srid_source.value));
			if(sr.equals(this.map.spatialReference)){ //same as map
				this.X.value=Math.round(evt.mapPoint.x * 1000) / 1000;
				this.Y.value=Math.round(evt.mapPoint.y * 1000) / 1000;
			}else{ // reprojection
				var params = new ProjectParameters();
				params.geometries = [geometry];
				params.outSR = sr;
				esriConfig.defaults.geometryService.project(params, lang.hitch(this, function(geometry){
					this.X.value=Math.round(geometry[0].x * 1000) / 1000;
					this.Y.value=Math.round(geometry[0].y * 1000) / 1000;
				}), lang.hitch(this, function(error){alert(this.nls.erreur3+":"+error)}));
			};
		},
		setMapXY: function(evt){
			if(!(this.X.value&&this.Y.value&&this.srid_source.value)){
				alert(this.nls.erreur1);
				return
			};
			sr=new SpatialReference(parseInt(this.srid_source.value));
			if(sr.equals(this.map.spatialReference)){ //Ajouter directement dessin sur la carte
				symbol = new SimpleMarkerSymbol();
				geometry = new Point(this.X.value,this.Y.value,sr)
				graphic = new Graphic(geometry, symbol);
				this.GraphicLayer.clear();
				this.GraphicLayer.add(graphic);
				this.map.centerAt(geometry);
			}else{ //convertir geometrie puis afficher sur la carte
				var params = new ProjectParameters();
				params.geometries = [new Point(this.X.value,this.Y.value,sr)];
				params.outSR = this.map.spatialReference;
				esriConfig.defaults.geometryService.project(params, lang.hitch(this, function(geometry){
					symbol = new SimpleMarkerSymbol();
					geometry = new Point(geometry[0].x,geometry[0].y,this.map.spatialReference)
					graphic = new Graphic(geometry, symbol);
					this.GraphicLayer.clear();
					this.GraphicLayer.add(graphic);
					this.map.centerAt(geometry);
				}), lang.hitch(this, function(error){alert(this.nls.erreur3+":"+error)}));
			}

		},
		
	   onClose: function() {
		   this.map.onClick = null;
		   this.map.setInfoWindowOnClick(true);
		   this.GraphicLayer.clear();
      },
	   onOpen: function() {
		   this.map.setInfoWindowOnClick(false);
		   this.GraphicLayer.clear();
      },
	  
	});

    return clazz;
  });