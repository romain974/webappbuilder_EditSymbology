define({
    "resume": "Localiser et convertir des coordonnées XY",
    "start": "Entrer des coordonnées XY et la projection associée",
	"convert_to": "Projection souhaitée",
	"convert_from": "Projection de départ",
	"convert":"Convertir",
	"localiser": "Afficher sur la carte",
	"getXY": "Cliquer sur la carte pour obtenir des coordonnées",
	"result": "Resultats",
	"erreur1": "Merci de renseigner les valeurs X, Y et la projection",
	"erreur2": "Merci de renseigner les valeurs X, Y et les projections de départ/arrivée",
	"erreur3": "GeometryService - erreur reprojection"
});