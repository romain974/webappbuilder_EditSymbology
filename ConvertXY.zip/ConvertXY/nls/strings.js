﻿define({
  root: ({
    resume: "Locate and convert XY coordinates",
    start: "Enter XY coordinate and spatial reference",
	convert_to: "Convert to projection",
	convert_from: "Convert from projection",
	convert:"Convert",
	localiser: "Show XY on map",
	getXY: "Click on map to get current XY ",
	result: "Results",
	erreur1: "Please set X,Y and Projection",
	erreur2: "Please set X,Y and Start/End Projection",
	erreur3: "GeometryService - reprojection error"
  }),
  "fr": 1,
});