﻿define({
  root: ({
    proj: "Projection list",
    proj2: "(1 line per projection: EPSG code; projection name) [separator ;]",
  }),
  "fr": 1,
});