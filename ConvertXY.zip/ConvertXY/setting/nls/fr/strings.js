define({
    "proj": "Liste des projections autorisées",
    "proj2": "(1 ligne par projection: code EPSG; nom de la projection - séparateur ;)",
});