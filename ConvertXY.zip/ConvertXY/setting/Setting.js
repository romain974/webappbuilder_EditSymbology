define([
    'dojo/_base/declare',
    'dijit/_WidgetsInTemplateMixin',
    'jimu/BaseWidgetSetting',
    'jimu/dijit/Message',
  ],
  function(
    declare,
    _WidgetsInTemplateMixin,
    BaseWidgetSetting,
    Message,
	LayerStructure) {
    return declare([BaseWidgetSetting, _WidgetsInTemplateMixin], {
      //these two properties is defined in the BaseWidget
      baseClass: 'jimu-widget-ConvertXY-setting',

      startup: function() {
        this.inherited(arguments);
		this.setConfig(this.config);
      },

      setConfig: function(config) {
        this.config = config;
		this.EPSG.value=this.config.EPSG;
      },

      getConfig: function() {
		this.config.EPSG=this.EPSG.value;
        return this.config;
      }

    });
  });