define([
    'jimu/BaseWidget',
    'dojo/_base/declare',
	'dijit/_WidgetsInTemplateMixin',
	'dojo/_base/lang',
	'dojo/on',
	'dojo',
	"jimu/dijit/FeaturelayerChooserFromMap",
	"./RendererChooser",
	"esri/layers/LayerDrawingOptions"
  ],
  function(BaseWidget, declare, _WidgetsInTemplateMixin, lang, on, dojo, LayerChooserFromMap,RendererChooser,LayerDrawingOptions) {

    var clazz = declare([BaseWidget, _WidgetsInTemplateMixin], {
      //these two properties is defined in the BaseWiget
      baseClass: 'jimu-widget-EditSymbology',
      name: 'EditSymbology',

      startup: function() {
        this.inherited(arguments);
		
		this.configDIV.style.display='none';
		this.layerNode=false;
		this.renderer_backup={};
		this.rendererChooser = new RendererChooser({
							type: "marker",
							fields:[],
							nls:this.nls,
							map:this.map
						}, this.rendererEditorNode);
		this.rendererChooser.reset();		
		//create layerlist
		this.layerChooser = new LayerChooserFromMap({
		createMapResponse: this.map.webMapResponse,
		multiple: false,
		showLayerFromFeatureSet: true
		}, this.layerchooserNode);
		
		//actions
		on(this.layerChooser,'tree-click',lang.hitch(this, this.EditSymbology));
		on(this.ApplySymbologyButton,'click',lang.hitch(this, this.ApplySymbology))
		on(this.reset,'click',lang.hitch(this, this.ResetSymbology))
		
      },  			  
		ResetSymbology: function() {
			//console.log(this.renderer_backup);
			if(this.layerNode.originOperLayer.selfType=="mapservice_dynamic"){
				var mapservice=this.layerNode.originOperLayer.mapService.layerInfo.layerObject;
				if(mapservice.layerDrawingOptions==undefined){
					service_layerDrawingOptions=[]
				}else{ service_layerDrawingOptions = mapservice.layerDrawingOptions;}
					service_layerDrawingOptions[this.layerNode.originOperLayer.subId]=this.renderer_backup[this.layer.id];
				mapservice.setLayerDrawingOptions(service_layerDrawingOptions);	
			}else{
				if(this.renderer_backup[this.layer.id]!=undefined){
					this.layer.setRenderer(this.renderer_backup[this.layer.id]);
					this.layer.refresh();
				};
			};
			this.EditSymbology();
		},  			  
		ApplySymbology: function() {
			if(this.layerNode.originOperLayer.selfType=="mapservice_dynamic"){
				var mapservice=this.layerNode.originOperLayer.mapService.layerInfo.layerObject;
				//console.log(mapservice);
				var layerDrawingOption = new LayerDrawingOptions();
				layerDrawingOption.renderer = this.rendererChooser.getRenderer();
				if(mapservice.layerDrawingOptions==undefined){
					service_layerDrawingOptions=[]
				}else{ service_layerDrawingOptions = mapservice.layerDrawingOptions;}
				//backup original layer renderer
				if(this.renderer_backup[this.layer.id]==undefined){
					this.renderer_backup[this.layer.id]=service_layerDrawingOptions[this.layerNode.originOperLayer.subId];
				}
				service_layerDrawingOptions[this.layerNode.originOperLayer.subId] = layerDrawingOption;
				mapservice.setLayerDrawingOptions(service_layerDrawingOptions);				
			}else{
				//backup original layer renderer
				if(this.renderer_backup[this.layer.id]==undefined){
					this.renderer_backup[this.layer.id]=this.layer.renderer;
				}
				this.layer.setRenderer(this.rendererChooser.getRenderer());
				this.layer.refresh();
			}
			
		},
		EditSymbology: function() {
			//console.log("Control layer capabilities");
			this.configDIV.style.display='block';
			this.layerName.innerHTML = this.layerChooser.getSelectedItems()[0].name;
			this.layerNode=this.layerChooser.getSelectedItems()[0].layerInfo;
			//get layer object
			this.layerNode.getLayerObject().then(lang.hitch(this, function(layer){
				//Get Renderer
				this.layer=layer;
				if (this.layerNode.originOperLayer.selfType!="mapservice_dynamic" || (this.layerNode.originOperLayer.selfType=="mapservice_dynamic"&& this.layer.canModifyLayer==true)){
					//Configure rendererChooser
					if(["esri.renderer.SimpleRenderer","esri.renderer.ClassBreaksRenderer","esri.renderer.UniqueValueRenderer"].includes(layer.renderer.declaredClass)){  //set layer renderer
						//console.log(this.layer.renderer);
						this.rendererChooser.showByRenderer(this.layer.renderer,this.layer.fields,this.layer);
						this.ApplySymbologyButton.style.display="block";
						this.reset.style.display="block";
					}else{  // set default renderer
						this.geometryType="";
						if(layer.geometryType=="esriGeometryPoint"){
							this.geometryType="marker";
						}else if(layer.geometryType=="esriGeometryPolyline"){
							this.geometryType="line";
						}else if(layer.geometryType=="esriGeometryPolygon"){
							this.geometryType="fill";
						};
						if (this.geometryType != ""){
							this.rendererChooser.showByType(this.geometryType, this.layer.fields,this.layer);
							this.ApplySymbologyButton.style.display="block";
							this.reset.style.display="block";
						}else{
							//Layer not editable
							this.ErrorMSG.innerHTML = this.nls.ErrorMSG;
							this.ApplySymbologyButton.style.display="none";
							this.reset.style.display="none";
							this.rendererChooser.reset();
						};
					}

				}else{
					//Layer not editable
					this.rendererChooser.reset();
					this.ErrorMSG.innerHTML = this.nls.ErrorMSG;
					this.ApplySymbologyButton.style.display="none";
					this.reset.style.display="none";
				};	
			}));
      },			  		  
		destroy: function() {
        this.inherited(arguments);
      },
	});

    return clazz;
  });
