﻿define({
        title: "Editeur de symbologie",
		chooseLayer: "Choisir couche",
		EditSymbolyAskLabel: "Modifier symbologie couche",
		ErrorMSG: "Symbologie non éditable sur cette couche",
		ApplySymbologyButtonLabel: "Appliquer symbologie à la couche",
		ResetButtonLabel: "Réinitialiser symbologie",
		addAllUniqueValues: "Ajouter les valeurs uniques",
		ErrorListUniqueValues: "Erreur lors du chargement des valeurs uniques",
		GenerateBreaksFromLayerLabel: "Suggérer à partir des données",
		range_Size: "Plage de valeurs - Taille",
		range_Color: "Plage de valeurs - couleurs",
		SuggestFromLayer: "Suggérer à partir des données"
});
