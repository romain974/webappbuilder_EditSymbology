﻿define({
    root:({
        title: "Edit symbology",
		chooseLayer: "Choose layer",
		EditSymbolyAskLabel: "Edit sombology for layer",
		ErrorMSG: "Symbology not editable for this layer",
		ApplySymbologyButtonLabel: "Apply symbology to layer",
		ResetButtonLabel: "Reset layer symbology",
		addAllUniqueValues: "Add unique values",
		ErrorListUniqueValues: "Error while searching unique value",
		GenerateBreaksFromLayerLabel: "Generate from values",
		SuggestFromLayer: "Suggest from layer values",
		range_Size: "Size",
		range_Color: "Color"
    }),
  "fr": 1,
});
