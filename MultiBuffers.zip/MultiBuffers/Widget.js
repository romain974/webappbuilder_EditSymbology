define([
    'jimu/BaseWidget',
    'dojo/_base/declare', 
	'dijit/_WidgetsInTemplateMixin',
	'jimu/LayerStructure',
	'esri/tasks/query',  
    'esri/tasks/QueryTask',
	'dojo/_base/lang',
	"dojo/_base/window",
	"dojo/dom",
	"dojo/on",
	'dojox/gfx',
	'dojo/query',
	'dojo/_base/html',
	'esri/symbols/jsonUtils',
	"dojo/request",
	"esri/toolbars/draw",
	"esri/graphic",
	"esri/layers/GraphicsLayer",
	"esri/layers/FeatureLayer",
	"esri/symbols/SimpleMarkerSymbol",
	"esri/symbols/SimpleLineSymbol",
	"esri/symbols/SimpleFillSymbol",
	"esri/geometry/geometryEngine",
	"esri/renderers/UniqueValueRenderer",
	"esri/graphicsUtils",
	'esri/config',
	"esri/tasks/Geoprocessor",
	"esri/tasks/FeatureSet",
	"jimu/dijit/FeaturelayerChooserFromMap",
	"jimu/dijit/SymbolChooser",
	"esri/geometry/Polygon",
	"dojo/domReady!",
	"dijit/form/Select"
  ],
  function(BaseWidget, declare, _WidgetsInTemplateMixin, LayerStructure, Query, QueryTask, lang, win, dom,on,gfx,query,html,jsonUtils, request, Draw, Graphic,GraphicsLayer, FeatureLayer, SimpleMarkerSymbol, SimpleLineSymbol, SimpleFillSymbol,geometryEngine, UniqueValueRenderer,graphicsUtils,esriConfig,Geoprocessor,FeatureSet,FeaturelayerChooserFromMap,SymbolChooser,Polygon) {

    var clazz = declare([BaseWidget, _WidgetsInTemplateMixin], {
      //these two properties is defined in the BaseWiget
      baseClass: 'jimu-widget-MultiBuffers',
      name: 'MultiBuffers',

      startup: function() {
        this.inherited(arguments);
		//Couche dessin
		this.GraphicLayer = new GraphicsLayer();
		this.BufferLayer = new GraphicsLayer();
		this.map.addLayer(this.BufferLayer);
		this.map.addLayer(this.GraphicLayer);
		//configurer liste des couches source pour la géométries
        this.layerChooser = new FeaturelayerChooserFromMap({
            createMapResponse: this.map.webMapResponse,
            multiple: false,
            showLayerFromFeatureSet: true
          }, this.source);
		//Parametres
		this.layers={};
		this.distances=[]; 
		this.rendererConfig={}; //[distance]=[symbol,label]
		this.SymbolChooser=new SymbolChooser({
			symbol: new SimpleFillSymbol()
		}, this.SymbolEditor);
		//configurer les actions "dessiner geometrie"
		this.point.onclick=lang.hitch({app:this,geom:"POINT"}, this.dessiner);
		this.ligne.onclick=lang.hitch({app:this,geom:"POLYLINE"}, this.dessiner);
		this.polygone.onclick=lang.hitch({app:this,geom:"POLYGON"}, this.dessiner);
		//configurer action selection à partir de la couche
		this.select.onclick=lang.hitch({app:this,geom:"EXTENT"}, this.selectionner);
		//configurer action add distance
		this.btnAddDistance.onclick=lang.hitch(this, this.addDistance);
		//configurer action stop edit symbol
		this.StopModifySymbolBtn.onclick=lang.hitch(this, function(){this.SymbolEditorDIV.style.display="none";});
		this.ModifySymbolBtn.onclick=lang.hitch(this, this.editSymbol);
		//Configurer action Reset Reset
		this.Reset.onclick=lang.hitch(this, this.doReset);
		
		this.Show.onclick=lang.hitch(this, this.Showbuffer, true);
		
		this.unit.onchange=lang.hitch(this, this.unitChanged);
		
		this.addlayer.onclick=lang.hitch(this, this.addLayerToMap);
		
		this.anglecheckbox.onchange=lang.hitch(this, this.SwowAngleConfig);
		this.s_angle.onchange=lang.hitch(this, this.AngleUpdated, this.s_angle);
		this.e_angle.onchange=lang.hitch(this, this.AngleUpdated, this.e_angle);
		//Configurer action OK
		//this.ok.onclick=lang.hitch(this, this.Extract);
		
		},
		AngleUpdated: function(input){
			  angle=parseFloat(input.value);
			  if(isNaN(angle)||angle>360||angle<0){
				  alert(this.nls.ErrorAngle);
				  input.value=0;
				  return;
			  }else{
				  this.Showbuffer();	
			  };		
			
		},
		SwowAngleConfig: function(){
			if(this.GraphicLayer.graphics.length>0){
				if(this.GraphicLayer.graphics[0].geometry.type.toUpperCase()!="POLYGON"&&this.GraphicLayer.graphics[0].geometry.type.toUpperCase()!="POINT"){
					alert(this.nls.InvalidAngleGeom);
					this.anglecheckbox.checked=false;
					this.angleDIV.style.display="none";
					return;
				};
			};
			if(this.anglecheckbox.checked){
				this.angleDIV.style.display="block";
			}else{
				this.angleDIV.style.display="none";
			}
			this.Showbuffer();
		},
		unitChanged: function(){
		  if (this.distances.length==0||this.GraphicLayer.graphics.length==0){
			  return
		  }; 	
			this.Showbuffer();
		},
		addLayerToMap: function(){
			if(this.layername.value.trim().length==0||this.layers[this.layername.value.trim()]!=undefined){
				alert(this.nls.InvalidLayerName);
				return;
			}else if(this.BufferLayer.graphics.length==0){
				alert(this.nls.InvalidGraphics);
				return;
			}
			layername=this.layername.value.trim();
			graphics=this.BufferLayer.graphics;
			//create renderer
			var renderer = new UniqueValueRenderer(null, "distance");
			for (d in this.rendererConfig){
				renderer.addValue({
					value: d,
					symbol: this.rendererConfig[d][0],
					label: String(this.rendererConfig[d][1]),
					description: String(this.rendererConfig[d][1])
				  });
				  //renderer.addValue(d,this.rendererConfig[d][0]);
			};
			renderer=renderer.toJson();
			//create featureset
			features=[];
			for(el in graphics){
				graphic=graphics[el];
				graphic.symbol=undefined; //remove graphic from 
				features.push(graphic.toJson())
			}
			//console.log(features);
			//create featurelayer
			var featureCollection = {
			  "layerDefinition": null,
			  "featureSet": {
				"features": features,
				"geometryType": "esriGeometryPolygon"
			  }
			};
			featureCollection.layerDefinition = {
			  "geometryType": "esriGeometryPolygon",
			  "objectIdField": "objectid",
			  "drawingInfo": {
				"renderer": renderer
			  },
			  "fields": [{
				"name": "objectid",
				"alias": "objectid",
				"type": "esriFieldTypeOID"
			  },{
				"name": "distance",
				"alias": "Distance",
				"type": "esriFieldTypeDouble"
			  },{
				"name": "label",
				"alias": "Label",
				"type": "esriFieldTypeString"
			  }]
			};

			/** //define a popup template
			var popupTemplate = new PopupTemplate({
			  title: "{title}",
			  description: "{description}"
			}); **/

			//create a feature layer based on the feature collection
			featureLayer = new FeatureLayer(featureCollection, {
			  id: layername,
			  //infoTemplate: popupTemplate
			});
			this.map.addLayer(featureLayer);
			this.layers[layername]=featureLayer;
			//console.log(featureLayer);
			//create table row
			  var s2 = '';
			  s2 = '<tr class="layer-tr">' +
				  '<td class="layername-td">' +
					'<div class="layername-div">'+layername+'</div>' +
				  '</td>' +
				  '<td class="action-td">' +
					'<div class="delete-div jimu-icon jimu-icon-delete"></div>' +
				  '</td>' +
				'</tr>';
			  var trDom2 = html.toDom(s2);
			  html.place(trDom2, this.LayersConfig);
			  var deleteDiv = query('.delete-div', trDom2)[0];		  
			  //delete action
			  this.own(on(deleteDiv, 'click', lang.hitch(this, function(event){
				event.stopPropagation();
				//remove layer from map
				this.map.removeLayer(this.layers[query('.layername-div', trDom2)[0].innerHTML]);
				//clean layers
				delete this.layers[query('.layername-div', trDom2)[0].innerHTML];
				//clean table
				html.destroy(trDom2);
				
			  })));
			  this.doReset();


		},
		doReset: function(){
			this.selected_tr=undefined;
			this.GraphicLayer.clear();
			this.BufferLayer.clear();
			this.distances=[];
			this.rendererConfig={};
			this.anglecheckbox.checked=false;
			this.angleDIV.style.display="none";
			html.empty(this.DistanceConfig);
		},
		editSymbol: function(){
			if(this.selected_tr==undefined){
				return
			}
			var symbolDiv = query('.symbol-div', this.selected_tr)[0];
			this._drawSymbolPreview(symbolDiv,this.SymbolChooser.getSymbol());
			d=query('.distance-div', this.selected_tr)[0].innerHTML;
			this.rendererConfig[d][0]=this.SymbolChooser.getSymbol();
			this.SymbolEditorDIV.style.display="none";
			this.Showbuffer();
		},
		addDistance: function(){
			d=parseFloat(this.distance.value);
			if(d<=0 || isNaN(d) ||this.distances.includes(d)){
				alert(this.nls.ErrorDistance);
				this.distance.value="";
				return
			};
			//add distance
			this.distances.push(d);
			//create table row
			  var s = '';
			  s = '<tr class="unique-symbol-tr">' +
				  '<td class="distance-td">' +
					'<div class="distance-div">'+d+'</div>' +
				  '</td>' +
				  '<td class="label-td">' +
					'<div class="label-div"><input class="label-edit" type="text" value="'+d+'"/></div>' +
				  '</td>' +
				  '<td class="symbol-td">' +
					'<div class="symbol-div"></div>' +
				  '</td>' +
				  '<td class="action-td">' +
					'<div class="delete-div jimu-icon jimu-icon-delete"></div>' +
				  '</td>' +
				'</tr>';
			  var trDom = html.toDom(s);
			  html.place(trDom, this.DistanceConfig);
			  var symbolDiv = query('.symbol-div', trDom)[0];
			  var deleteDiv = query('.delete-div', trDom)[0];
			  var labeledit = query('.label-edit', trDom)[0];
			  //Symbol drawing
			  this._drawSymbolPreview(symbolDiv,new SimpleFillSymbol());
			    //configure renderer
				this.rendererConfig[d]=[new SimpleFillSymbol(),d];
			  //edit label action
			  this.own(on(labeledit, 'change', lang.hitch(this, function(event){
				console.log("edit label");
				event.stopPropagation();
				d=query('.distance-div', trDom)[0].innerHTML;
				label=query('.label-edit', trDom)[0].value;
				this.selected_tr=trDom;
				this.rendererConfig[d][1]=label.trim();
				this.Showbuffer();
			  })));				  
			  //edit renderer action
			  this.own(on(symbolDiv, 'click', lang.hitch(this, function(event){
				event.stopPropagation();
				d=query('.distance-div', trDom)[0].innerHTML;
				this.selected_tr=trDom;
				symbol=this.rendererConfig[d][0];
				//console.log("Edit symbol");
				this.SymbolEditorDIV.style.display="block";
				this.SymbolChooser.showBySymbol(symbol);
			  })));			  
			  //delete action
			  this.own(on(deleteDiv, 'click', lang.hitch(this, function(event){
				event.stopPropagation();
				//clean distances values
				index = this.distances.indexOf(parseFloat(query('.distance-div', trDom)[0].innerHTML));
				if (index > -1) {
				  this.distances.splice(index, 1);
				};
				//clean renderer config
				this.rendererConfig[query('.distance-div', trDom)[0].innerHTML]=undefined;
				//clean table
				html.destroy(trDom);
				this.Showbuffer();
			  })));
			this.distance.value="";
			this.Showbuffer();
		},
    _cloneSymbol:function(symbol){
      if(!symbol){
        return null;
      }
      var jsonSym = symbol.toJson();
      var clone = jsonUtils.fromJson(jsonSym);
      return clone;
    },

    _drawSymbolPreview:function(previewNode, sym){
      var node = previewNode;
      var symbol = this._cloneSymbol(sym);
      html.empty(node);

      var sWidth = 80;
      var sHeight = 30;
      if (symbol.type === "simplemarkersymbol") {
        // extra padding for the outline width
        sWidth = Math.min(symbol.size + 12, 125);
        sHeight = sWidth;
      } else if (symbol.type === "picturemarkersymbol") {
        if (!symbol.url || symbol.url === "http://" ||
            (symbol.url.indexOf("http://") === -1 &&
             symbol.url.indexOf("https://") === -1 &&
             symbol.url.indexOf("data:") === -1)) {
          // bad URL
          return;
        }
        sWidth = Math.min(Math.max(symbol.width, symbol.height), 125);
        sHeight = sWidth;
      } else if (symbol.type === "simplelinesymbol" || symbol.type === "cartographiclinesymbol") {
        sWidth = 190;
        sHeight = 20;
      }

      if(sWidth > 60){
        sWidth = 60;
      }

      var surface = gfx.createSurface(node, sWidth, sHeight);
      if (gfx.renderer === "vml") {
        // Fixes an issue in IE where the shape is partially drawn and
        // positioned to the right of the table cell
        var source = surface.getEventSource();
        html.setStyle(source, "position", "relative");
        html.setStyle(source.parentNode, "position", "relative");
      }
      var shapeDesc = null;

      // if(symbolUtils.isSimpleLineSymbol(symbol) || symbolUtils.isCartographicLineSymbol(symbol)){
      //   shapeDesc = this._getLineShapeDesc(symbol);
      // }
      // else{
      shapeDesc = jsonUtils.getShapeDescriptors(symbol);
      // }

      var gfxShape;
      try {
        gfxShape = surface.createShape(shapeDesc.defaultShape)
                   .setFill(shapeDesc.fill).setStroke(shapeDesc.stroke);
      } catch (e) {
        surface.clear();
        surface.destroy();
        return;
      }

      var dim = surface.getDimensions();
      var transform = {
        dx: dim.width / 2,
        dy: dim.height / 2
      };

      var bbox = gfxShape.getBoundingBox(),
        width = bbox.width,
        height = bbox.height;
      if (width > sWidth || height > sHeight) {
        var actualSize = width > height ? width : height;
        var refSize = sWidth < sHeight ? sWidth : sHeight;
        var scaleBy = (refSize - 5) / actualSize;
        lang.mixin(transform, {
          xx: scaleBy,
          yy: scaleBy
        });
      }

      gfxShape.applyTransform(transform);
      return surface;
    },
	  Showbuffer: function(from_button=false){
		  this.BufferLayer.clear();
		  if (this.distances.length==0||this.GraphicLayer.graphics.length==0){
			  if(from_button){ //show error only when button clicked by user
				alert(this.nls.ErrorGeomDist);
			  };
			  return
		  };
		  // test if user angle enabled
		  limit_angle=false;
		  if(this.anglecheckbox.checked){
			  s_angle=parseFloat(this.s_angle.value);
			  e_angle=parseFloat(this.e_angle.value);
			  if(isNaN(s_angle)||isNaN(e_angle)||e_angle==s_angle){
				  alert(this.nls.ErrorAngle);
				  return;
				  };
			  if(s_angle>e_angle){
				tmp=s_angle;
				s_angle=e_angle;
				e_angle=tmp;
			  };
			  if(s_angle!=0||e_angle!=360){
				   limit_angle=true;
			  }
		  };
		  //console.log(limit_angle);
		  //get geometries
		  geoms=[]
		  geoms_centroid=[]
		  for(el in this.GraphicLayer.graphics){
			  //params.geometries.push(this.GraphicLayer.graphics[el].geometry)
			  geoms.push(this.GraphicLayer.graphics[el].geometry);
			  if(limit_angle){
				  if(this.GraphicLayer.graphics[el].geometry.type.toUpperCase()=="POLYGON"){
						geoms_centroid.push(this.GraphicLayer.graphics[el].geometry.getCentroid());
				  }else{
					geoms_centroid.push(this.GraphicLayer.graphics[el].geometry);
				  }	
			  };
		  }
		  //geom=geometryEngine.union(geoms)
		  //compute angle limit polygon from geom centroids
		  geoms_angle_limit=[];
		  if(limit_angle){
			  d_max=Math.max.apply(null, this.distances);
			  //console.log(d_max);
			  for(el in geoms_centroid){
				  pt1=geoms_centroid[el];
				  tmp=pt1.offset(0,d_max*100000);
				  ring=[pt1];
				  for (var i = s_angle; i < e_angle; i+=45) {   //add on point every 45° to avoid errors if angle>180°
						console.log(i);
						ring.push(geometryEngine.rotate(tmp,-i,pt1));
					}
				  ring.push(geometryEngine.rotate(tmp,-e_angle,pt1))
				  polygon=new Polygon(pt1.spatialReference);
				  polygon.addRing(ring);
				  //console.log(polygon);
				  geoms_angle_limit.push(polygon);
			  };
		  };
		  //sorted dist buffer
		  sorted_dists=this.distances.sort((a,b)=>a-b);
		  //graphics=[];
		  oid=0;
		  for(g in geoms){ //Buffer each geometry
			  geom=geoms[g];
			  if(geom.type.toUpperCase()=="POLYGON"){
					negative=geom;
			  }else{
				negative=null;
			  }
			  for(d in sorted_dists){
				  //console.log(sorted_dists[d]);
				  buff=geometryEngine.geodesicBuffer(geom, sorted_dists[d], this.unit.value, true);
				  if(negative==null){
					  buff_ok=buff;
				  }else{
					  buff_ok=geometryEngine.difference(buff,negative);
				  }
				  if(limit_angle){ // limit angle
					  buff_ok=geometryEngine.intersect(buff_ok,geoms_angle_limit[g]);
				  }
				  var graphic = new Graphic(buff_ok, this.rendererConfig[sorted_dists[d]][0], {distance:sorted_dists[d],objectid:oid,label:this.rendererConfig[sorted_dists[d]][1]});
				  this.BufferLayer.add(graphic);
				  //graphics.push(graphic);
				  negative=buff;
				  oid=oid+1;
			  };
		  };

		  this.map.setExtent(graphicsUtils.graphicsExtent(this.BufferLayer.graphics));
	  },
		
	  selectionner: function(){
		if (this.app.layerChooser.getSelectedItems().length>0){
			if(this.app.GraphicLayer.graphics.length>0){
				if(confirm(this.app.nls.DeleteGeomConfirm)){
					this.app.GraphicLayer.clear();
					this.app.BufferLayer.clear();
				}else{
					return 
				}
			};
			this.app.toolbar = new Draw(this.app.map);
			this.app.toolbar.on("draw-complete", lang.hitch(this,this.app.queryGeom));
			this.app.map.setInfoWindowOnClick(false);
			this.app.toolbar.activate(Draw[this.geom.toUpperCase()]);
			//this.app.map.hideZoomSlider();
		}else{
			alert(this.app.nls.NoselectLayer);
		};
	  },
	  dessiner: function(){
		if(this.app.GraphicLayer.graphics.length>0){
			if(this.app.GraphicLayer.graphics[0].geometry.type.toUpperCase()!=this.geom.toUpperCase()){
				if(confirm(this.app.nls.DeleteGeomConfirm)){
					this.app.GraphicLayer.clear();
					this.app.BufferLayer.clear();
				}else{
					return 
				}
			};
		};
		this.app.toolbar = new Draw(this.app.map);
		this.app.map.setInfoWindowOnClick(false);
		this.app.toolbar.activate(Draw[this.geom.toUpperCase()]);
		this.app.toolbar.on("draw-complete", lang.hitch(this.app,this.app.addToMap));
        //this.app.map.hideZoomSlider();
	  },
      addToMap: function(evt) {
          var symbol;
          this.toolbar.deactivate();
          //this.map.showZoomSlider();
		  this.BufferLayer.clear();
          switch (evt.geometry.type) {
            case "point":
            case "multipoint":
              symbol = new SimpleMarkerSymbol();
              break;
            case "polyline":
              symbol = new SimpleLineSymbol();
			  this.anglecheckbox.checked=false;  //desactivate angle
			  this.angleDIV.style.display="none";
              break;
            default:
              symbol = new SimpleFillSymbol();
              break;
          }
          var graphic = new Graphic(evt.geometry, symbol);
          this.GraphicLayer.add(graphic);
		  this.map.setInfoWindowOnClick(true);
		  if(this.distances.length>0){
			  this.Showbuffer();
		  }
        },
		
		queryGeom: function(evt){
          var symbol;
		  this.app.evt=evt;
          this.app.toolbar.deactivate();
          //this.app.map.showZoomSlider();
		  this.app.map.setInfoWindowOnClick(true);
		  layerNode=this.app.layerChooser.getSelectedItems()[0].layerInfo;
		  console.log(this.app.layerChooser.getSelectedItems()[0]);
		  if(!layerNode){
			  alert(this.app.nls.NoselectLayer);
			  return
		  }
		  layerNode.getLayerObject().then(lang.hitch(this, function(layer){
			  var queryTask = new QueryTask(layer.url)
			  var query = new Query();
			  query.geometry = this.app.evt.geometry;
			  query.returnGeometry = true;
			  queryTask.execute(query, lang.hitch(this,this.app.getGeom),function(){alert(this.app.nls.LayerError)} );

		  }));
		},
		
		getGeom: function(res){
		  if(res.features.length==0){
			  alert(this.app.nls.NoObjects)
			  return
		  };
			for(el in res.features){
				evt={"geometry":res.features[el].geometry}
				this.app.addToMap(evt);
			};
		},
		
	   onClose: function() {
		//this.map.removeLayer(this.GraphicLayer);
		//this.map.removeLayer(this.BufferLayer);
		//this.GraphicLayer.setVisibility(false);
		//this.BufferLayer.setVisibility(false);
	   this.toolbar.deactivate();
      },	   
	  onOpen: function() {
		//this.GraphicLayer.setVisibility(true);
		//this.BufferLayer.setVisibility(true);
		//this.map.addLayer(this.BufferLayer);
		//this.map.addLayer(this.GraphicLayer);
      },
	  
	});

    return clazz;
  });
